//
//  Gyro.swift
//  conor_ca2
//
//  Created by Student on 16/05/2023.
//

import SwiftUI
import CoreMotion

struct Page {
    let id: Int
    let title: String
    let text: String
}

//data model for the pages
let pages = [
    Page(id: 0, title: "Character Design", text: "This is the first page."),
    Page(id: 1, title: "Background Design", text: "This is the second page."),
    Page(id: 2, title: "Storyboard Design", text: "This is the third page.")
]

//create an ObservableObject that will handle the gyroscope data
class GyroManager: ObservableObject {
    private var motionManager: CMMotionManager
    private let navigationThreshold: Double = 0.5
    @Published var currentPage: Page

    init() {
        self.motionManager = CMMotionManager()
        self.currentPage = pages[0]
    }

    func startMonitoring() {
        if self.motionManager.isGyroAvailable {
            self.motionManager.gyroUpdateInterval = 0.1
            self.motionManager.startGyroUpdates(to: OperationQueue.current!) { (data, error) in
                if let myData = data {
                    if myData.rotationRate.y > self.navigationThreshold {
                        self.navigateToNextPage()
                    } else if myData.rotationRate.y < -self.navigationThreshold {
                        self.navigateToPreviousPage()
                    }
                }
            }
        }
    }

    func stopMonitoring() {
        if self.motionManager.isGyroAvailable {
            self.motionManager.stopGyroUpdates()
        }
    }

    private func navigateToNextPage() {
        if currentPage.id < pages.count - 1 {
            currentPage = pages[currentPage.id + 1]
        }
    }

    private func navigateToPreviousPage() {
        if currentPage.id > 0 {
            currentPage = pages[currentPage.id - 1]
        }
    }
}



struct Gyro: View {
    @ObservedObject var gyroManager = GyroManager()
    
    
    func sendNotification() {
        let center = UNUserNotificationCenter.current()

        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                let content = UNMutableNotificationContent()
                content.title = "Navigated to Gyro Page"
                content.body = "You have successfully navigated to the Gyro page."
                content.categoryIdentifier = "message"
                content.sound = UNNotificationSound.default

                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

                center.add(request)
            } else {
                print("D'oh")
            }
        }
    }

    var body: some View {
        NavigationView {
            
            ZStack {
                
                Image("gradient 1")
                    .resizable()
                    .ignoresSafeArea()
                
                VStack {
                    Text("Tilt the phone left or right to navigate between pages")
                        .padding(.bottom)
                    Text(gyroManager.currentPage.title)
                        .font(.largeTitle)
                    Text(gyroManager.currentPage.text)
                        .font(.body)
                }
                .onAppear {
                    gyroManager.startMonitoring()
                    sendNotification()
                }
                .onDisappear {
                    gyroManager.stopMonitoring()
                }
                .navigationBarTitle("Gyro Navigation")
            }
        }
    }
}



struct Gyro_Previews: PreviewProvider {
    let username: String

    static var previews: some View {
        Gyro()
    }
}
