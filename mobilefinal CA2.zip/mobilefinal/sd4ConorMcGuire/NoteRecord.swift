
//

import SwiftUI


import SwiftUI
import AVFoundation

struct NoteRecord: View {
    @ObservedObject private var recorder = AudioRecorder()
    var body: some View {
            VStack {
                Button(action: {
                    if self.recorder.recording == false {
                        self.recorder.startRecording()
                    } else {
                        self.recorder.stopRecording()
                    }
                }) {
                    Text(self.recorder.recording ? "Stop Recording" : "Start Recording")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(self.recorder.recording ? Color.red : Color.green)
                        .cornerRadius(10)
                }
                
                if self.recorder.recording == false {
                    Button(action: {
                        self.recorder.playRecordedAudio()
                    }) {
                        Text("Play Recording")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    
                    List(self.recorder.recordings, id: \.self) { recording in
                        Text(recording.lastPathComponent)
                    }
                }
            }
            .padding()
            .onAppear {
                self.recorder.loadRecordings()
            }
        }
}


class AudioRecorder: ObservableObject {
    private var audioRecorder: AVAudioRecorder?
    private var audioPlayer: AVAudioPlayer?
    @Published var recording = false
    @Published var recordings: [URL] = []
    
    //let recordingsKey = "RecordingsKey"
    
    func startRecording() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100.0,
            AVNumberOfChannelsKey: 2,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ] as [String : Any]

        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder?.record()
            recording = true
            
            recordings.append(audioFilename) // Add this line
            saveRecordings() // Save the updated recordings array
        } catch {
            print("Failed to start recording")
        }
    }

    let recordingsKey = "RecordingsKey"
    
    func stopRecording() {
        audioRecorder?.stop()
        recording = false
    }
    
    func playRecordedAudio() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: audioFilename)
            audioPlayer?.play()
        } catch {
            print("Failed to play recorded audio")
        }
    }
    
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    func saveRecordings() {
           let encodedData = try? JSONEncoder().encode(recordings)
           UserDefaults.standard.set(encodedData, forKey: recordingsKey)
       }
        
    func loadRecordings() {
            guard let encodedData = UserDefaults.standard.data(forKey: recordingsKey) else { return }
            if let decodedRecordings = try? JSONDecoder().decode([URL].self, from: encodedData) {
                recordings = decodedRecordings
            }
        }
}

struct NoteRecord_Previews: PreviewProvider {
    static var previews: some View {
        NoteRecord()
    }
}
