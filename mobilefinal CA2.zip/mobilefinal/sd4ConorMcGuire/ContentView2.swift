//
//  ContentView2.swift
//  sd4ConorMcGuire
//
//  Created by Student on 11/05/2023.
//

import SwiftUI

struct ContentView2: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ContentView2_Previews: PreviewProvider {
    static var previews: some View {
        ContentView2()
    }
}
