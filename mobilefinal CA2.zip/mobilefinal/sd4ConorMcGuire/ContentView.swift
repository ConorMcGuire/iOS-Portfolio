//
//  ContentView.swift
//  sd4ConorMcGuire
//
//  Created by Student on 22/02/2023.
//

import SwiftUI



extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape( RoundedCorner(radius: radius, corners: corners) )
    }
}
struct RoundedCorner: Shape {

    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}


struct ContentView: View {
    @State private var isZoomed = false
    @State var currentDate = Date.now
        let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let images = ["bg1 1", "bg2", "bg3 1", "bg4 1"]
    @State private var currentindex = 0

    
    var body: some View {
        
            NavigationView {
                
                ZStack {
                    
                    Image("gradient 1")
                        .resizable()
                        .ignoresSafeArea()
                    
                    VStack {
                        Text("2D Animation Design")
                            .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility2/*@END_MENU_TOKEN@*/)
                            .padding(.bottom, 50)
                            .font(Font.custom("Charming Childish", size: 24))
                            .multilineTextAlignment(.center)
                        
                        
                        NavigationLink(destination: CharDesignView()) {
                            VStack{
                                Image("charDesignBanner")
                                    .resizable()
                                //                            .aspectRatio(contentMode: .fill)
                                    .aspectRatio(contentMode: .fill)
                                    .scaleEffect(isZoomed ? 1.8 : 1)
                                    .onTapGesture {
                                        withAnimation{
                                            isZoomed.toggle()
                                        }
                                    }
                                    .frame(width: 300, height: 100, alignment:
                                            .topLeading).padding(4)
                                    .border(Color.purple, width: 4)
                                    .clipped()
                                
                                Text("Character Design")
                                    .foregroundColor(.black)
                            }
                        }
                        
                        
                        NavigationLink(destination: BgDesignView()) {
                            
                            //                        Image("bgDesignBanner")
                            //                            .resizable()
                            //                            .aspectRatio(contentMode: .fill)
                            //                            .frame(width: 300, height: 100).padding(4)
                            //                            .border(Color.purple, width: 4)
                            //                            .clipped()
                            Image(images[currentindex])
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .padding(.top, -80.0)
                                .frame(width: 300, height: 100, alignment: .center).padding(4)
                                .border(Color.purple, width: 4)
                                .clipped()
                            
                        }.onReceive(timer) { _ in
                            let newindex = (currentindex + 1) % images.count
                            currentindex = newindex
                        }
                        Text("Background Design")
                        
                        NavigationLink(destination: StoryboardDesignView()) {
                            Image("storyboardBanner")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 300, height: 100).padding(.top, 10)
                                .border(Color.purple, width: 4)
                                .clipped()
                            //                        .resizable()
                            //                        .aspectRatio(contentMode: .fill)
                            //                        .frame(width: 300, height: 100).padding(.top, 10)
                            //                        .border(Color.purple, width: 4)
                            //                        .clipped()
                            //                        .cornerRadius(20, corners: [.topLeft, .bottomRight])
                            /*.overlay(
                             RoundedRectangle(.cornerRadius(20, corners: [.topLeft, .bottomRight]))
                             .stroke(Color.purple, lineWidth: 4)
                             )*/
                        }
                        Text("Storyboards")
                        
                    }
                    .padding()
                }
            }
        }
    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        }
    }

