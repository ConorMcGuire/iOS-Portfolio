////
////  Example.swift
////  SeanMcAvoyMobileCA1
////
////  Created by Seán McAvoy on 23/03/2023.
////
//
//import SwiftUI
//import AVFoundation
//
//struct Example2: View {
//    
//    @State private var showCamera = false
//        
//        var body: some View {
//            VStack {
//                if showCamera {
//                    CameraView(showCamera: $showCamera)
//                } else {
//                    Button("Open Camera") {
//                        self.showCamera.toggle()
//                    }
//                }
//            }
//        }
//}
//
//struct CameraView: View {
//    @Binding var showCamera: Bool
//    @State private var captureSession: AVCaptureSession?
//
//    var body: some View {
//        ZStack {
//            CameraPreview(session: captureSession)
//            VStack {
//                Spacer()
//                Button("Take Photo") {
//                    // Code to capture photo goes here
//                }
//                .padding()
//                .background(Color.white)
//                .clipShape(Circle())
//                .padding(.bottom, 50)
//                Button("Close") {
//                    self.showCamera = false
//                }
//            }
//        }
//        .onAppear {
//            self.captureSession = AVCaptureSession()
//            self.captureSession?.sessionPreset = .photo
//
//            guard let captureDevice = AVCaptureDevice.default(for: .video),
//                  let input = try? AVCaptureDeviceInput(device: captureDevice) else {
//                return
//            }
//
//            let photoOutput = AVCapturePhotoOutput()
//            if self.captureSession?.canAddOutput(photoOutput) == true {
//                self.captureSession?.addOutput(photoOutput)
//            }
//
//            self.captureSession?.addInput(input)
//            self.captureSession?.startRunning()
//        }
//        .onDisappear {
//            self.captureSession?.stopRunning()
//        }
//    }
//}
//
//struct CameraPreview: UIViewRepresentable {
//    var session: AVCaptureSession?
//
//    func makeUIView(context: Context) -> AVCaptureVideoPreviewLayer {
//        let previewLayer = AVCaptureVideoPreviewLayer(session: session!)
//        previewLayer.videoGravity = .resizeAspectFill
//        return previewLayer
//    }
//
//    func updateUIView(_ uiView: AVCaptureVideoPreviewLayer, context: Context) {
//        uiView.session = session!
//    }
//}
//
//    
//    
