//
//  Login.swift
//
//  Created by Student on 16/05/2023.
//

import SwiftUI
import UserNotifications

//create a view model to handle the login logic
class LoginViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""

    func login() -> Bool {
        let storedUsername = UserDefaults.standard.string(forKey: "username")
        let storedPassword = UserDefaults.standard.string(forKey: "password")

        if username == storedUsername && password == storedPassword {
            sendNotification()
            return true
        } else {
            return false
        }
    }

    func register(username: String, password: String) {
        UserDefaults.standard.set("Conor", forKey: "username")
        UserDefaults.standard.set("password", forKey: "password")
    }

    func sendNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Logged In"
        content.body = "You have successfully logged in."

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request)
    }
}

//create a SwiftUI view for the login page
struct Login: View {
    @StateObject var viewModel = LoginViewModel()
//    @State var isLoggedIn: Bool? = nil
    @State var isLoggedIn = false
    @State var isRegistering = false
    @State var registerUsername = ""
    @State var registerPassword = ""

    var body: some View {
        NavigationStack {
            
            ZStack {
                
                Image("gradient 1")
                    .resizable()
                    .ignoresSafeArea()
                
                VStack {
                    
                    Text("2D Animation Design")
                        .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility2/*@END_MENU_TOKEN@*/)
                        .padding(.bottom, 50)
                        .font(Font.custom("Charming Childish", size: 24))
                        .multilineTextAlignment(.center)
                    
                    if isRegistering {
                        TextField("New Username", text: $registerUsername)
                            .padding()
                            .border(Color.black, width: 0.5)
                        SecureField("New Password", text: $registerPassword)
                            .padding()
                            .border(Color.black, width: 0.5)
                        Button(action: {
                            viewModel.register(username: registerUsername, password: registerPassword)
                            isRegistering = false
                        }) {
                            Text("Register")
                        }
                        Button(action: {
                            isRegistering = false
                        }) {
                            Text("Cancel")
                        }
                    } else {
                        TextField("Username", text: $viewModel.username)
                            .padding()
                            .border(Color.black, width: 0.5)
                        SecureField("Password", text: $viewModel.password)
                            .padding()
                            .border(Color.black, width: 0.5)
                        Button(action: {
                            if viewModel.login() {
                                isLoggedIn = true
                                
                            }
                        }) {
                            Text("Log in")
                        }
                        NavigationLink(destination: ContentView(), isActive: $isLoggedIn, label: {EmptyView()})
                        
                        Button(action: {
                            isRegistering = true
                        }) {
                            Text("Register")
                        }
                    }
                }
                .padding()
            }
        }
    }
}


//        VStack {
//            TextField("Username", text: $viewModel.username)
//                .padding()
//                .border(Color.gray, width: 0.5)
//            SecureField("Password", text: $viewModel.password)
//                .padding()
//                .border(Color.gray, width: 0.5)
//            Button(action: {
//                isLoggedIn = viewModel.login()
//            }) {
//                Text("Log in")
//            }
//        }
//        .padding()
//        .alert(isPresented: $isLoggedIn) {
//            Alert(title: Text("Logged in"), message: Text("You have successfully logged in."), dismissButton: .default(Text("OK")))
//        }
//    }
//}

//ask user's permission to send notifications
func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    let center = UNUserNotificationCenter.current()
    center.requestAuthorization(options: [.alert, .sound]) { granted, error in
        if granted {
            print("We have permission")
        } else {
            print("Permission denied")
        }
    }
    return true
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
