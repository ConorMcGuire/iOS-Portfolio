//
//  ContentView.swift
//  RobertMCCA1
//
//  Created by Student on 15/03/2023.
//

import SwiftUI
import UIKit
import AVFoundation

extension Font {
    static func avenirNext(size: Int) -> Font {
        return Font.custom("Avenir Next", size: CGFloat(size))
    }
    
    static func avenirNextRegular(size: Int) -> Font {
        return Font.custom("AvenirNext-Regular", size: CGFloat(size))
    }
}
struct StoryboardDesignView: View {
    
    @GestureState var isDetectingLongPress = false
        @State var img = "img1"
        
        let imgArray = [["img1","img2","img3"],["img4","img5","img6"],["img7"]];
        
       
        

        
        
        var body: some View {
            GeometryReader { geometry in
                ZStack {

                    VStack {
                        
                        Text("Storyboards")
                            .font(.avenirNext(size: 40))
                            .fontWeight(.bold)
                            .foregroundColor(Color.purple)
                            .multilineTextAlignment(.leading)
                        
                        ForEach (imgArray, id: \.self) { array in
                            HStack {
                                // create 3 image placement on every row.
                                ForEach (0..<3, id: \.self) { index in
                                    if index < array.count {
                                        // Image
                                        Image(array[index])
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: geometry.size.width * 0.3, height:  geometry.size.width * 0.3)
                                            .clipped()
                                            .gesture(LongPressGesture(minimumDuration: 60)
                                                .updating($isDetectingLongPress) { currentstate, gestureState,
                                                    transaction in
                                                    
                                                    gestureState = currentstate
                                                    transaction.animation = Animation.spring()
                                                }
                                                .onChanged({ _ in
                                                    img = array[index]
                                                })
                                            )
                                        
                                    } else {
                                        // when there is no image left, then create clear rectangles.
                                        Rectangle().fill(Color.clear)
                                            .frame(width: geometry.size.width * 0.3, height:  geometry.size.width * 0.3)
                                    }
                                }
                            }.frame(width:geometry.size.width,alignment: .center)
                                .padding(.top, -30)
                        }
                    }.padding(.top)
                        .frame(height: geometry.size.height, alignment: .top)
                        .blur(radius: isDetectingLongPress ? 5 : 0)
                    
                    // Preview Image
                    if isDetectingLongPress {
                        ImagePreview(img: $img)
                            .frame(width: geometry.size.width * 0.95, height: geometry.size.height * 0.95)
                            .padding(.top, -400)
                            .transition(.scale)
                    }
                    
                    VStack{
                        
                            HStack {
                                Image("person 1")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 55, height: 55)
                                    .clipShape(Circle())
                                    .shadow(radius: 4)
                                
                                VStack(alignment: .leading) {
                                    Text("2D Animation Degree")
                                        .font(.avenirNext(size: 12))
                                        .foregroundColor(.black)
                                    Text("Robert McAteer")
                                        .font(.avenirNext(size: 17))
                                }
                            }
                            Text("Mobile • Portfolio")
                                .font(.avenirNextRegular(size: 12))
                                .foregroundColor(.black)
                            
                            Text(loremIpsum1)
                                .foregroundColor(Color(hue: 0.772, saturation: 0.957, brightness: 0.396))
                                .multilineTextAlignment(.center)
                                .lineLimit(nil)
                                .font(.avenirNextRegular(size: 17))
                                .background(Color .purple)
                        
                        Button("Play Voice Over"){
                            
                            let utterance = AVSpeechUtterance(string: "This is where the creator describes their work. Here they can explain their thoughts about the importance of their storyboard. How the characters behave and the storyline they want to portray")
                            utterance.voice = AVSpeechSynthesisVoice(language: "en-AU")
                            utterance.rate = 0.5
                            
                            let synthesizer = AVSpeechSynthesizer()
                            synthesizer.speak(utterance)
                            
                        }.buttonStyle(.borderedProminent)
                            .controlSize(.small)

                        
                        
                        
                    }
                    .overlay(
                              RoundedRectangle(cornerRadius: 10)
                              .stroke(Color(hue: 0.816, saturation: 1.0, brightness: 1.0), lineWidth: 2)
                             )
                    .padding(.horizontal)
                    .padding(.top, 450)
                    //.background(Image("middle"))
                    
                    
                }.padding(.top, 30.0).edgesIgnoringSafeArea(.all)
                    
                    
            }
        }
}

struct ImagePreview : View {
    @Binding var img : String
    var body: some View {
        ZStack {
            Image(img)
                .resizable()
                .aspectRatio(contentMode: .fit)
        }
        .padding(8)
        .background(Color.purple)
        .cornerRadius(5)
        .shadow(radius: 5)
    }
}

let loremIpsum1 = """




This is where the creator describes their work. Here they can explain their thoughts about the importance of their storyboard. How the characters behave and the storyline they want to portray



"""
