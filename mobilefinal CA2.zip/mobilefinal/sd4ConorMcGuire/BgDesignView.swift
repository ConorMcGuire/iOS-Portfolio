//
//  ContentView.swift
//  SeanMcAvoyMobileCA1
//
//  Created by Seán McAvoy on 23/03/2023.
//

import SwiftUI

struct BgDesignView: View {
    var body: some View {
        ZStack{
            
//            Image("bg1")
//                .resizable()
//                .ignoresSafeArea()
            
            VStack {
                    
                    Text("2D Animation Backgrounds")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color(hue: 0.816, saturation: 1.0, brightness: 1.0))
                                    .multilineTextAlignment(.center)
                                    //.padding(.top, 40.0)
                    NavigationView {
                    
                        VStack(alignment: .center)
                        {
                            
                            
                            HStack{
                                Text("Here you will learn all about backgrounds in 2D Animation Development.\n\nInduction: \n2D animation backgrounds are the visual elements that make up the backdrop of a 2D animated scene.")
                                    .padding()
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color(hue: 0.816, saturation: 1.0, brightness: 1.0), lineWidth: 2)
                                    )
                                    .frame(width: 420, height: 250)
                                    .font(.system(size: 20))
                                    
                            }
                            .padding(.top, 1)
                            
                            
                                    NavigationLink(destination: BackgroundImportance())
                                    {
                                        Text("Why are Backgrounds Important?")
                                            .font(.title2)
                                            .padding(10.0)
                                            .frame(width: 410.0)
                                            .background(Color(hue: 0.816, saturation: 1.0, brightness: 1.0))
                                            .foregroundColor(.black)
                                            .cornerRadius(10)
                                    }
                                    .padding(.bottom, 20.0)
                            
                            
                            NavigationLink(destination: Techniques())
                            {
                                Text("Techniques Used To Create Backgrounds")
                                    .font(.title2)
                                    .padding(.vertical, 10.0)
                                    .frame(width: 410.0)
                                    .background(Color(hue: 0.816, saturation: 1.0, brightness: 1.0))
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }
                            .padding(.bottom, 20.0)
                            
                            NavigationLink(destination: Example())
                            {
                                Text("Example Backgrounds!")
                                    .font(.title2)
                                    .padding(10.0)
                                    .frame(width: 410.0)
                                    .background(Color(hue: 0.816, saturation: 1.0, brightness: 1.0))
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }
                            NavigationLink(destination: NoteRecord())
                            {
                                Text("Record your Ideas")
                                    .font(.title2)
                                    .padding(10.0)
                                    .frame(width: 410.0)
                                    .background(Color(hue: 0.816, saturation: 1.0, brightness: 1.0))
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                            }
                            ZStack{
                                Image("gradient 1")
                                    .resizable(resizingMode: .stretch)
                                    .ignoresSafeArea()
                                
                                VStack{
                                    Text("Principles of Background Design")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color.white)
                                        .multilineTextAlignment(.center)
                                    YoutubeVideo(videoID: "vdChVpYGs7g")
                                                .frame(width: 350, height: 180)
                                }
                                .padding(.vertical, 10.0)
                                .padding(.horizontal, 5.0)
                                .frame(width: 400.0)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color(hue: 0.816, saturation: 1.0, brightness: 1.0), lineWidth: 2)
                                )
                            }
                        }
                        //.padding(.bottom, 300.0)
                        //.background(Color.pink)
//                        .navigationBarTitle("Backgrounds")
//                        .navigationBarHidden(true)
                        
                        
                    }
                  
                    
                } //.background(Color.clear)
            
            
        }
        
        
        
        
        }
    }


struct bgDesignView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


