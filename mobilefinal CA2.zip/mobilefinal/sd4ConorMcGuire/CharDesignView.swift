//https://levelup.gitconnected.com/swiftui-create-an-image-carousel-using-a-timer-ed546aacb389

//https://medium.com/@amosgyamfi/learning-swiftui-spring-animations-the-basics-and-beyond-4fb032212487

import CoreHaptics
import SwiftUI
import UserNotifications

//extension Font {
//    static func avenirNext(size: Int) -> Font {
//        return Font.custom("Avenir Next", size: CGFloat(size))
//    }
//
//    static func avenirNextRegular(size: Int) -> Font {
//        return Font.custom("AvenirNext-Regular", size: CGFloat(size))
//    }
//}


struct CharDesignView: View {
    @State private var engine: CHHapticEngine?
    
    var body: some View {
        ScrollView {
            
            GeometryReader { geometry in
             ImageCarouselView(numberOfImages: 3) {
                Image("start")
                  .resizable()
                  .scaledToFill()
                  .frame(width: geometry.size.width, height:geometry.size.height)
                  .clipped()
                 Image("sword back")
                 .resizable()
                  .scaledToFill()
                 .frame(width: geometry.size.width, height:         geometry.size.height)
                 .clipped()
                 Image("head")
                 .resizable()
                  .scaledToFill()
                 .frame(width: geometry.size.width, height:         geometry.size.height)
                 .clipped()
                 Image("end")
                 .resizable()
                 .scaledToFill()
                 .frame(width: geometry.size.width, height: geometry.size.height)
                 .clipped()
                }
             }.frame(height: 600, alignment: .center)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image("person")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 55, height: 55)
                        .clipShape(Circle())
                        .shadow(radius: 4)
                        .onTapGesture(perform: simpleSuccess)
                        .onAppear(perform: prepareHaptics)
                        .onTapGesture(perform: complexSuccess)
                    
                    VStack(alignment: .leading) {
                        Text("2D Animation Degree")
                            .font(.avenirNext(size: 12))
                            .foregroundColor(.black)
                        Text("Sean Stephens")
                            .font(.avenirNext(size: 17))
                    }
                }
                
                Text("22 February 2023 • Portfolio")
                    .font(.avenirNextRegular(size: 12))
                    .foregroundColor(.black)
                
                Text("Character Design")
                    .font(.avenirNext(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(Color.purple)
                    .multilineTextAlignment(.center)
                    .onTapGesture(perform: simpleSuccess)
                    .onAppear(perform: prepareHaptics)
                    .onTapGesture(perform: complexSuccess)
                
                Text(loremIpsum)
                    .foregroundColor(Color(hue: 0.772, saturation: 0.957, brightness: 0.396))
                    .multilineTextAlignment(.center)
                    .lineLimit(nil)
                    .font(.avenirNextRegular(size: 17))
                    .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.817, saturation: 0.818, brightness: 0.866, opacity: 0.338)/*@END_MENU_TOKEN@*/)
                
                
                
                
                Image("enable icon")
                    .resizable(resizingMode: .stretch)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 60)
                    .padding(.horizontal, 70)
                
                Button("Enable Notifications"){
                    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
                        if success {
                            print("All set!")
                        } else if let error = error {
                            print(error.localizedDescription)
                        }
                    }
                }
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.831, saturation: 0.662, brightness: 0.986, opacity: 0.503)/*@END_MENU_TOKEN@*/)
                .font(.avenirNextRegular(size: 15))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 105)
                
                Image("send icon")
                    .resizable(resizingMode: .stretch)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 60)
                    .padding(.horizontal, 80)
                
                Button("Schedule Notification"){
                    let content = UNMutableNotificationContent()
                    content.title = "2D Animation"
                    content.subtitle = "Check out my Portfolio"
                    content.sound = UNNotificationSound.default
                    
                    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
                    
                    let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                    
                    UNUserNotificationCenter.current().add(request)
                }
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.846, saturation: 0.473, brightness: 0.984, opacity: 0.498)/*@END_MENU_TOKEN@*/)
                .font(.avenirNextRegular(size: 15))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 100)
                
                
                
                
            }
            .padding(.horizontal)
            .padding(.top, 16.0)
            .background(Image("middle"))
        }.padding(.top, 30.0).edgesIgnoringSafeArea(.all).background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.white/*@END_MENU_TOKEN@*/)
    }
    func simpleSuccess(){
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
    func prepareHaptics(){
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else {return}
        
        do{
            engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("There was an error creating the engine: \(error.localizedDescription)")
        }
    }
    func complexSuccess(){
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else {return}
        
        var events = [CHHapticEvent]()
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 1)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 1)
        let event = CHHapticEvent(eventType: .hapticTransient, parameters: [intensity, sharpness], relativeTime: 0)
        events.append(event)
        
        do{
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine?.makePlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            print("Failed to play pattern \(error.localizedDescription)")
        }
    }
}

struct CharDesignView_Previews: PreviewProvider {
    static var previews: some View {
        CharDesignView()
    }
}

let loremIpsum = """


This is where the creator can communicate with the user, regarding the importance of 2D Character Design. This part of the application is used to display a creators journey in designing and completing their character design.

The creator can type out their thoughts in any way they see fit, in order to truly grasp the users attention and pull them into the world of 2D Animation and Character Design. I feel this will be very appealing to any Creator as it gives them a platform to express their feelings and thoughts regarding their chosen designs.

The same text will be displayed throughout the duration of the carousel in order to give the user a feeling of consistency when using the application.


"""






