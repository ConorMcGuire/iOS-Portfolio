//
//  Example.swift
//  SeanMcAvoyMobileCA1
//
//  Created by Seán McAvoy on 23/03/2023.
//

import SwiftUI
import AVFoundation

struct Example2: View {
    
    @State private var showCamera = false
    var body: some View {
        VStack{
            
            Text("Showcase Background")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            VStack{
                Text("Induction")
                    .font(.title3)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                
                Text("Upload a photo of your own personal hand created background!")
                    .font(.system(size: 18))
                    .multilineTextAlignment(.leading)
                    .padding(.top,2)
            }
            .padding(.vertical, 10.0)
            .padding(.horizontal, 2.0)
            .frame(width: 415.0)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color(hue: 0.816, saturation: 1.0, brightness: 1.0), lineWidth: 2)
            )
            
            Spacer()
            VStack{
                //                if showCamera {
                //                                CameraView(showCamera: $showCamera)
                //                            } else {
                //                                Button("Open Camera") {
                //                                    self.showCamera.toggle()
                //                                }
                //                            }
                //                        }
                
                
            }
            .frame(width: 415.0, height: 500)
            .background(
                Rectangle()
                    .fill(Color(hue: 0.816, saturation: 1.0, brightness: 1.0).opacity(0.2))
                    .cornerRadius(10)
            )
            
        }
        
        
        
    }
    
    
    struct Example2_Previews: PreviewProvider {
        static var previews: some View {
            Example2()
        }
    }
    
    
    
    struct CameraView: View {
        @Binding var showCamera: Bool
        @State private var captureSession: AVCaptureSession?
        
        var body: some View {
            ZStack {
                CameraPreview(session: captureSession)
                VStack {
                    Spacer()
                    Button("Take Photo") {
                        // Code to capture photo goes here
                    }
                    .padding()
                    .background(Color.white)
                    .clipShape(Circle())
                    .padding(.bottom, 50)
                    Button("Close") {
                        self.showCamera = false
                    }
                }
            }
            .onAppear {
                self.captureSession = AVCaptureSession()
                self.captureSession?.sessionPreset = .photo
                
                guard let captureDevice = AVCaptureDevice.default(for: .video),
                      let input = try? AVCaptureDeviceInput(device: captureDevice) else {
                    return
                }
                
                let photoOutput = AVCapturePhotoOutput()
                if self.captureSession?.canAddOutput(photoOutput) == true {
                    self.captureSession?.addOutput(photoOutput)
                }
                
                self.captureSession?.addInput(input)
                self.captureSession?.startRunning()
            }
            .onDisappear {
                self.captureSession?.stopRunning()
            }
        }
    }
    
    //    struct CameraPreview: UIViewRepresentable {
    //        var session: AVCaptureSession?
    //
    //        func makeUIView(context: Context) -> AVCaptureVideoPreviewLayer {
    //            let previewLayer = AVCaptureVideoPreviewLayer(session: session!)
    //            previewLayer.videoGravity = .resizeAspectFill
    //            return previewLayer
    //        }
    //
    //        func updateUIView(_ uiView: AVCaptureVideoPreviewLayer, context: Context) {
    //            uiView.session = session!
    //        }
    //
    //    }
    
    struct CameraPreview: UIViewRepresentable {
        let session: AVCaptureSession
        
        func makeUIView(context: Context) -> AVCaptureVideoPreviewLayer {
            let previewLayer = AVCaptureVideoPreviewLayer(session: session)
            previewLayer.videoGravity = .resizeAspectFill
            return previewLayer
        }
        
        func updateUIView(_ uiView: AVCaptureVideoPreviewLayer, context: Context) {
            uiView.session = session
        }
        
        typealias UIViewType = AVCaptureVideoPreviewLayer
    }
    
}
